/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package DBO;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.sql.*;

/**
 *
 * @author Tran Bao
 */
public class DB {

    protected static String hostName = "localhost";
    protected static String sid = "orcl";
    protected static String userName = "test06";
    protected static String password = "123";

    /**
     * //@param args the command line arguments
     */
    public static Connection getOracleConnection() throws ClassNotFoundException, SQLException {
        Class.forName("oracle.jdbc.driver.OracleDriver");

        //Xóa chữ g chỗ thing nếu mà code không chạy được ha. <đã xóa, nếu k chạy thì thêm vào>
        String connectionURL = "jdbc:oracle:thin:@" + hostName + ":1521:" + sid;

        Connection conn = (Connection) DriverManager.getConnection(connectionURL, userName, password);

        return conn;
    }

    public static void getUserByID(String Id) {
        System.out.println("get Connection...");
        try {
            Connection conn = getOracleConnection();
            System.out.println("Success");

            Statement st = conn.createStatement();

            System.out.println("Success statement");

            ResultSet rs = st.executeQuery("select * from NguoiDung where MAND = '" + Id + "'");

            System.out.println("Success resultset");

            while (rs.next()) {
                System.out.println(rs.getString(1));
                System.out.println(rs.getString(2));
                System.out.println(rs.getString(3));
                System.out.println(rs.getString(4));
                System.out.println(rs.getString(5));
                System.out.println(rs.getString(6));

            }
            rs.close();
            st.close();
            conn.close();

        } catch (Exception e) {
            System.out.println("Connection failed! " + e);
        }
    }

    public static void SingIn(String HoTen, String TenTK, String Email, String Pass, String Address, String CMND_T, String CMND_S, String SDT, String DoB,String Role) {
        System.out.println("get Connection...");
        try {
            Connection conn = getOracleConnection();
            System.out.println("Success connected!");
            
            
            Statement st = conn.createStatement();

            System.out.println("Success statement");
            
            CallableStatement  stmt=conn.prepareCall("{call  dangky('" + HoTen + "', '" + TenTK + "','" + Email + "','" + Pass + "','" + Address + "','" + CMND_T + "','" + CMND_S + "', '" + SDT + "', '" + DoB + "','"+Role+"')}");
            stmt.execute();
            //st.executeQuery("begin dangky('" + HoTen + "', '" + TenTK + "','" + Email + "','" + Pass + "','" + Address + "','" + CMND_T + "','" + CMND_S + "', '" + SDT + "', '" + DoB + "','"+Role+"');  end;");
            

            System.out.println("Add data Sucessfully!");

            st.close();
            conn.close();

        } catch (Exception e) {
            System.out.println("Add data failed!  " + e);
        }
    }

    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("get Connection...");
        try {
            List<Objects.Cars> cars = new ArrayList<Objects.Cars>();
            cars = DB.getCars();

            for (Objects.Cars car : cars) {
                System.out.println(car.getMaLX());
            }

        } catch (Exception e) {
            System.out.println("Connection failed! " + e);
        }
    }

    public static List<Objects.Cars> getCars() {
        List<Objects.Cars> listCars = new ArrayList<Objects.Cars>();

        System.out.println("get Connection...");
        try {
            Connection conn = getOracleConnection();
            System.out.println("Success");

            Statement st = conn.createStatement();

            System.out.println("Success statement");

            ResultSet rs = st.executeQuery("select * from LoaiXe");

            System.out.println("Success resultset");

            while (rs.next()) {
                // String MaLX = rs.getString(1);
                // String TenLX = rs.getString(2);
                //int SoCho = rs.getInt(3);
                //int SoLuong =rs.getInt(4);
                //float Gia = rs.getFloat(5);
                //float NgoaiGio = rs.getFloat(6);
                //String Img = rs.getString(7);

                // Objects.Cars c = new Objects.Cars(MaLX,TenLX,SoCho,SoLuong,Gia,NgoaiGio);
                //listCars.add(c);
                String MaLX = rs.getString(1);
                String TenLx = rs.getString(2);
                String SoCho = rs.getString(3);
                String SoLuong = rs.getString(4);
                String Gia = rs.getString(5);
                String NgoaiGio = rs.getString(6);
                //String Img = rs.getString(7);

                Objects.Cars c = new Objects.Cars(MaLX, TenLx, SoCho, SoLuong, Gia, NgoaiGio);

                listCars.add(c);

            }

            rs.close();
            st.close();
            conn.close();

            System.out.println("Get cars successfully!");

            return listCars;

        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Connection failed! " + e);
            System.out.print("get cars data failed");
        }

        return null;
    }
    
    public static List<Objects.Customer> getCustomer()
    {
        List<Objects.Customer> customers = new ArrayList<Objects.Customer>();
        System.out.println("get Connection...");
        try {
            Connection conn = getOracleConnection();
            System.out.println("Success");

            Statement st = conn.createStatement();

            System.out.println("Success statement");

            ResultSet rs = st.executeQuery("select * from NguoiDung where Role='"+KhachHang+"'");

            System.out.println("Success resultset");

            while (rs.next()) {
                
                String MaND = rs.getString(1);
                String TenND = rs.getString(2);
                String TenTK = rs.getString(3);
                String Email = rs.getString(4);
                String MatKhau = rs.getString(5);
                String DiaChi = rs.getString(7);
                String CCCD_T = rs.getString(8);
                String CCCD_S=rs.getString(9);
                String SoDT=rs.getString(10);
                String NgaySinh = rs.getString(11);
                

                Objects.Customer c = new Objects.Customer(MaND, TenND, TenTK, Email, MatKhau, DiaChi, SoDT, NgaySinh)
            }
        }
            catch(Exception e)
                    {
                    System.out.print("Get customers failed!");
                    }

            rs.close();
            st.close();
            conn.close();

            System.out.println("Get cars successfully!");

        
    }

    public static Objects.Cars getCarFromID(String Id) {
        Objects.Cars c = new Objects.Cars();

        System.out.println("get Connection...");
        try {
            Connection conn = getOracleConnection();
            System.out.println("Success");

            Statement st = conn.createStatement();

            System.out.println("Success statement");

            ResultSet rs = st.executeQuery("select * from LoaiXe where MaLX='" + Id + "'");

            System.out.println("Success resultset");

            while (rs.next()) {
                String MaLX = rs.getString(1);
                String TenLx = rs.getString(2);
                String SoCho = rs.getString(3);
                String SoLuong = rs.getString(4);
                String Gia = rs.getString(5);
                String NgoaiGio = rs.getString(6);
                //String Img = rs.getString(7);

                c = new Objects.Cars(MaLX, TenLx, SoCho, SoLuong, Gia, NgoaiGio);
            }

            rs.close();
            st.close();
            conn.close();

            System.out.println("Get cars successfully!");

            return c;

        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Connection failed! " + e);
            System.out.print("get cars data failed");
        }

        return null;
    }
}
