/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Objects;

/**
 *
 * @author Tran Bao
 */
public class Customer {
    private String MaNV;
    private String TenNV;
    private String TenTK;
    private String Email;
    private String MatKhau;
    private String DiaChi;
    private String CMND_T;
    private String CMND_S;
    private String SoDT;
    private String NgaySinh;

    public Customer(String MaNV, String TenNV, String TenTK, String Email, String MatKhau, String DiaChi, String CMND_T, String CMND_S, String SoDT, String NgaySinh) {
        this.MaNV = MaNV;
        this.TenNV = TenNV;
        this.TenTK = TenTK;
        this.Email = Email;
        this.MatKhau = MatKhau;
        this.DiaChi = DiaChi;
        this.CMND_T = CMND_T;
        this.CMND_S = CMND_S;
        this.SoDT = SoDT;
        this.NgaySinh = NgaySinh;
    }

    public Customer() {
    }

    public Customer(String MaNV, String TenNV, String TenTK, String Email, String MatKhau, String DiaChi, String SoDT, String NgaySinh) {
        this.MaNV = MaNV;
        this.TenNV = TenNV;
        this.TenTK = TenTK;
        this.Email = Email;
        this.MatKhau = MatKhau;
        this.DiaChi = DiaChi;
        this.SoDT = SoDT;
        this.NgaySinh = NgaySinh;
    }

    public String getMaNV() {
        return MaNV;
    }

    public void setMaNV(String MaNV) {
        this.MaNV = MaNV;
    }

    public String getTenNV() {
        return TenNV;
    }

    public void setTenNV(String TenNV) {
        this.TenNV = TenNV;
    }

    public String getTenTK() {
        return TenTK;
    }

    public void setTenTK(String TenTK) {
        this.TenTK = TenTK;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getMatKhau() {
        return MatKhau;
    }

    public void setMatKhau(String MatKhau) {
        this.MatKhau = MatKhau;
    }

    public String getDiaChi() {
        return DiaChi;
    }

    public void setDiaChi(String DiaChi) {
        this.DiaChi = DiaChi;
    }

    public String getCMND_T() {
        return CMND_T;
    }

    public void setCMND_T(String CMND_T) {
        this.CMND_T = CMND_T;
    }

    public String getCMND_S() {
        return CMND_S;
    }

    public void setCMND_S(String CMND_S) {
        this.CMND_S = CMND_S;
    }

    public String getSoDT() {
        return SoDT;
    }

    public void setSoDT(String SoDT) {
        this.SoDT = SoDT;
    }

    public String getNgaySinh() {
        return NgaySinh;
    }

    public void setNgaySinh(String NgaySinh) {
        this.NgaySinh = NgaySinh;
    }
    
    
    
}
