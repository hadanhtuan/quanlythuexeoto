/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Objects;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Tran Bao
 */
public class listCarRental {
        public static List<Objects.Cars> cars = new ArrayList<Objects.Cars>();
        public static List<Integer> soluong = new ArrayList<Integer>();
}
