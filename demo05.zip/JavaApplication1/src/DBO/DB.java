/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package DBO;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Tran Bao
 */
public class DB {

    protected static String hostName = "localhost";
    protected static String sid = "orcl";
    protected static String userName = "test07";
    protected static String password = "123";

    /**
     * //@param args the command line arguments
     */
    public static Connection getOracleConnection() throws ClassNotFoundException, SQLException {
        Class.forName("oracle.jdbc.driver.OracleDriver");

        //Xóa chữ g chỗ thing nếu mà code không chạy được ha. <đã xóa, nếu k chạy thì thêm vào>
        String connectionURL = "jdbc:oracle:thin:@" + hostName + ":1521:" + sid;

        Connection conn = (Connection) DriverManager.getConnection(connectionURL, userName, password);

        return conn;
    }

    public static void getUserByID(String Id) {
        System.out.println("get Connection...");
        try {
            Connection conn = getOracleConnection();
            System.out.println("Success");

            Statement st = conn.createStatement();

            System.out.println("Success statement");

            ResultSet rs = st.executeQuery("select * from NguoiDung where MAND = '" + Id + "'");

            System.out.println("Success resultset");

            while (rs.next()) {
                System.out.println(rs.getString(1));
                System.out.println(rs.getString(2));
                System.out.println(rs.getString(3));
                System.out.println(rs.getString(4));
                System.out.println(rs.getString(5));
                System.out.println(rs.getString(6));

            }
            rs.close();
            st.close();
            conn.close();

        } catch (Exception e) {
            System.out.println("Connection failed! " + e);
        }
    }

    public static void SignUp(String HoTen, String TenTK, String Email, String Pass, String Address, String CMND_T, String CMND_S, String SDT, String DoB, String Role) {
        System.out.println("get Connection...");
        try {
            Connection conn = getOracleConnection();
            System.out.println("Success connected!");

            Statement st = conn.createStatement();

            System.out.println("Success statement");

            CallableStatement stmt = conn.prepareCall("{call  dangky('" + HoTen + "', '" + TenTK + "','" + Email + "','" + Pass + "','" + Address + "','" + CMND_T + "','" + CMND_S + "', '" + SDT + "', '" + DoB + "','" + Role + "')}");
            stmt.execute();
            //st.executeQuery("begin dangky('" + HoTen + "', '" + TenTK + "','" + Email + "','" + Pass + "','" + Address + "','" + CMND_T + "','" + CMND_S + "', '" + SDT + "', '" + DoB + "','"+Role+"');  end;");

            System.out.println("Add data Sucessfully!");

            st.close();
            conn.close();

        } catch (Exception e) {
            System.out.println("Add data failed!  " + e);
        }
    }
    
    public static void RentCars(String MaND, String NgayBD, String NgayKT,String listMaLX, String listSL) {
        System.out.println("get Connection...");
        try {
            Connection conn = getOracleConnection();
            System.out.println("Success connected!");

            Statement st = conn.createStatement();

            System.out.println("Success statement created!");

//            CallableStatement stmt = conn.prepareCall("{call  thuexe('"+MaND+"', '"+NgayBD+"', '"+NgayKT+"', '"+listMaLX+"', '"+listSL+"')}");
//            
//            stmt.execute();
            
            try {
                CallableStatement stmt = conn.prepareCall("{call  thuexe('" + MaND + "', '" + NgayBD + "', '" + NgayKT + "', '" + listMaLX + "', '" + listSL + "')}");                stmt.execute();
               stmt.execute();
                System.out.println("Rent car successfully!");
            } catch (SQLException e) {
                System.out.println("Rent car failed!  " + e);
            }



            st.close();
            conn.close();

        } catch (Exception e) {
            System.out.println("Rent car failed!  " + e);
        }
    }


    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("get Connection...");
        try {
            List<Objects.Cars> cars = new ArrayList<Objects.Cars>();
            cars = DB.getCars();

            for (Objects.Cars car : cars) {
                System.out.println(car.getMaLX());
            }

        } catch (Exception e) {
            System.out.println("Connection failed! " + e);
        }
    }

    public static List<Objects.Cars> getCars() {
        List<Objects.Cars> listCars = new ArrayList<Objects.Cars>();

        System.out.println("get Connection...");
        try {
            Connection conn = getOracleConnection();
            System.out.println("Success");

            Statement st = conn.createStatement();

            System.out.println("Success statement");

            ResultSet rs = st.executeQuery("select * from LoaiXe");

            System.out.println("Success resultset");

            while (rs.next()) {
              
                String MaLX = rs.getString(1);
                String TenLx = rs.getString(2);
                String SoCho = rs.getString(3);
                String SoLuong = rs.getString(4);
                String Gia = rs.getString(5);
                String NgoaiGio = rs.getString(6);
                String Img = rs.getString(7);
               
                Objects.Cars c = new Objects.Cars(MaLX, TenLx, SoCho, SoLuong, Gia, NgoaiGio,Img);
               
                listCars.add(c);

            }

            rs.close();
            st.close();
            conn.close();

            System.out.println("Get cars successfully!");

            return listCars;

        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Connection failed! " + e);
           
        }
         System.out.print("get cars data failed");
        return null;
    }

    public static List<Objects.User> getCustomer() {
        List<Objects.User> customers = new ArrayList<Objects.User>();
        System.out.println("get Connection...");
        String MaND = "";
        String TenND = "";
        String TenTK = "";
        String Email = "";
        String MatKhau = "";
        String DiaChi = "";
        String CMND_T = "";
        String CMND_S = "";
        String SoDT = "";
        String NgaySinh = "";
        try {
            Connection conn = getOracleConnection();

            System.out.println("Success connected");

            Statement st = conn.createStatement();

            System.out.println("Success statement");

            ResultSet rs = st.executeQuery("select * from NguoiDung where Role='KHACHHANG'");

            System.out.println("Success resultset");

            while (rs.next()) {
                MaND = rs.getString(1);
                TenND = rs.getString(2);
                TenTK = rs.getString(3);
                Email = rs.getString(4);
                MatKhau = rs.getString(5);
                DiaChi = rs.getString(7);
                CMND_T = rs.getString(8);
                CMND_S = rs.getString(9);
                SoDT = rs.getString(10);
                NgaySinh = rs.getString(11);
                System.out.println(rs.getString(1));

//                 public Customer(String MaKH, String TenNV, String TenTK, String Email, String MatKhau,
//                         String DiaChi, String CMND_T, String CMND_S, String SoDT, String NgaySinh) {
                Objects.User c = new Objects.User(MaND, TenND, TenTK, Email, MatKhau, DiaChi, CMND_T, CMND_S, SoDT, NgaySinh);

                customers.add(c);

            }
            rs.close();
            st.close();
            conn.close();
            System.out.println("Set customers successfully!");
            return customers;

        } catch (ClassNotFoundException | SQLException e) {
            System.out.print("Get customers failed!");
        }

        System.out.println("Get customers failed!");

        return null;
    }
    
    public static List<Objects.User> getCustomerContainChar(String value) {
        String checkValue = value.toLowerCase();
        List<Objects.User> customers = new ArrayList<Objects.User>();
        System.out.println("get Connection...");
        String MaND = "";
        String TenND = "";
        String TenTK = "";
        String Email = "";
        String MatKhau = "";
        String DiaChi = "";
        String CMND_T = "";
        String CMND_S = "";
        String SoDT = "";
        String NgaySinh = "";
        try {
            Connection conn = getOracleConnection();

            System.out.println("Success connected");

            Statement st = conn.createStatement();

            System.out.println("Success statement");

            ResultSet rs = st.executeQuery("select * from NguoiDung where Role='KHACHHANG' and Lower(TenND) like '%"+checkValue+"%'");

            System.out.println("Success resultset");

            while (rs.next()) {
                MaND = rs.getString(1);
                TenND = rs.getString(2);
                TenTK = rs.getString(3);
                Email = rs.getString(4);
                MatKhau = rs.getString(5);
                DiaChi = rs.getString(7);
                CMND_T = rs.getString(8);
                CMND_S = rs.getString(9);
                SoDT = rs.getString(10);
                NgaySinh = rs.getString(11);
                System.out.println(rs.getString(1));

//                 public Customer(String MaKH, String TenNV, String TenTK, String Email, String MatKhau,
//                         String DiaChi, String CMND_T, String CMND_S, String SoDT, String NgaySinh) {
                Objects.User c = new Objects.User(MaND, TenND, TenTK, Email, MatKhau, DiaChi, CMND_T, CMND_S, SoDT, NgaySinh);

                customers.add(c);

            }
            rs.close();
            st.close();
            conn.close();
            System.out.println("Set customers successfully!");
            return customers;

        } catch (ClassNotFoundException | SQLException e) {
            System.out.print("Get customers failed!");
        }

        System.out.println("Get customers failed!");

        return null;
    }
    
    public static void SignIn(String username, String password) {
        try {
            Connection conn = getOracleConnection();
            System.out.println("Success connected!");

            Statement st = conn.createStatement(java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,
			              java.sql.ResultSet.CONCUR_READ_ONLY);

            ResultSet rs = st.executeQuery("select mand, role from nguoidung where tentk = '"+username+ "' and matkhau = '"+password+"'");
            
            if (rs.isBeforeFirst() == false) {
                JOptionPane.showMessageDialog(null, "Sai tai khoan hoac mat khau", "Canh Bao", JOptionPane.ERROR_MESSAGE);
                return;
            }
            while (rs.next()) {

                Objects.User.Instance = new Objects.User();

                Objects.User.Instance.setMaND(rs.getString(1));
                Objects.User.Instance.setRole(rs.getString(2));
            }

            st.close();
            conn.close();

        } catch (Exception e) {
            System.out.println("Add data failed!  " + e);
        }
        
    }

    public static Objects.Cars getCarFromID(String Id) {
        Objects.Cars c = new Objects.Cars();

        System.out.println("get Connection...");
        try {
            Connection conn = getOracleConnection();
            System.out.println("Success");

            Statement st = conn.createStatement();

            System.out.println("Success statement");

            ResultSet rs = st.executeQuery("select * from LoaiXe where MaLX='" + Id + "'");

            System.out.println("Success resultset");

            while (rs.next()) {
                String MaLX = rs.getString(1);
                String TenLx = rs.getString(2);
                String SoCho = rs.getString(3);
                String SoLuong = rs.getString(4);
                String Gia = rs.getString(5);
                String NgoaiGio = rs.getString(6);
                String Img = rs.getString(7);

                c = new Objects.Cars(MaLX, TenLx, SoCho, SoLuong, Gia, NgoaiGio,Img);
            }

            rs.close();
            st.close();
            conn.close();

            System.out.println("Get cars successfully!");

            return c;

        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Connection failed! " + e);
            System.out.print("get cars data failed");
        }

        return null;
    }
}
