/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package test;

import com.formdev.flatlaf.FlatLightLaf;
import com.formdev.flatlaf.icons.FlatAbstractIcon;
import javax.swing.UIManager;
import view.formLogIn;
import view.formMenuManager;

/**
 *
 * @author phamq
 */
public class main {
    public static void main(String[] args) {
//       com.formdev.flatlaf.FlatDarculaLaf.setup();
        formMenuManager frm = new formMenuManager();
        frm.setVisible(true);
        
    }
}
