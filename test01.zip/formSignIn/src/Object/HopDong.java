/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Object;

/**
 *
 * @author Tran Bao
 */
public class HopDong {
    private String MaHopDong;
    private String MaKH;
    private String MaNV;
    private String MaDX;
    private String NgayHopDong;
    private String ND_HopDong;
    private String HTTT;
    private double TraTruoc;

    public HopDong(String MaHopDong, String MaKH, String MaNV, String MaDX, String NgayHopDong, String ND_HopDong, String HTTT, double TraTruoc) {
        this.MaHopDong = MaHopDong;
        this.MaKH = MaKH;
        this.MaNV = MaNV;
        this.MaDX = MaDX;
        this.NgayHopDong = NgayHopDong;
        this.ND_HopDong = ND_HopDong;
        this.HTTT = HTTT;
        this.TraTruoc = TraTruoc;
    }

    public HopDong() {
    }

    public String getMaHopDong() {
        return MaHopDong;
    }

    public void setMaHopDong(String MaHopDong) {
        this.MaHopDong = MaHopDong;
    }

    public String getMaKH() {
        return MaKH;
    }

    public void setMaKH(String MaKH) {
        this.MaKH = MaKH;
    }

    public String getMaNV() {
        return MaNV;
    }

    public void setMaNV(String MaNV) {
        this.MaNV = MaNV;
    }

    public String getMaDX() {
        return MaDX;
    }

    public void setMaDX(String MaDX) {
        this.MaDX = MaDX;
    }

    public String getNgayHopDong() {
        return NgayHopDong;
    }

    public void setNgayHopDong(String NgayHopDong) {
        this.NgayHopDong = NgayHopDong;
    }

    public String getND_HopDong() {
        return ND_HopDong;
    }

    public void setND_HopDong(String ND_HopDong) {
        this.ND_HopDong = ND_HopDong;
    }

    public String getHTTT() {
        return HTTT;
    }

    public void setHTTT(String HTTT) {
        this.HTTT = HTTT;
    }

    public double getTraTruoc() {
        return TraTruoc;
    }

    public void setTraTruoc(double TraTruoc) {
        this.TraTruoc = TraTruoc;
    }
    
    
}
