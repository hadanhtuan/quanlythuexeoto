/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Object;

/**
 *
 * @author Tran Bao
 */
public class KhachHang {
    private String MaND;
    private String TenND;
    private String TenTK;
    private String Email;
    private String MatKhau;
    private String Role;
    private String DiaChi;
    private String CCCD_T;
    private String CCCD_S;
    private String SDT;
    private int BlackList;

    public KhachHang() {
    }
    
    

    public KhachHang(String MaND, String TenND, String TenTK, String Email, String MatKhau, String DiaChi, String CCCD_T, String CCCD_S, String SDT) {
        this.MaND = MaND;
        this.TenND = TenND;
        this.TenTK = TenTK;
        this.Email = Email;
        this.MatKhau = MatKhau;
        this.DiaChi = DiaChi;
        this.CCCD_T = CCCD_T;
        this.CCCD_S = CCCD_S;
        this.SDT = SDT;
        this.BlackList=0;
        this.Role="KHACHHANG";
    }

    public String getMaND() {
        return MaND;
    }

    public void setMaND(String MaND) {
        this.MaND = MaND;
    }

    public String getTenND() {
        return TenND;
    }

    public void setTenND(String TenND) {
        this.TenND = TenND;
    }

    public String getTenTK() {
        return TenTK;
    }

    public void setTenTK(String TenTK) {
        this.TenTK = TenTK;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getMatKhau() {
        return MatKhau;
    }

    public void setMatKhau(String MatKhau) {
        this.MatKhau = MatKhau;
    }

    public String getDiaChi() {
        return DiaChi;
    }

    public void setDiaChi(String DiaChi) {
        this.DiaChi = DiaChi;
    }

    public String getCCCD_T() {
        return CCCD_T;
    }

    public void setCCCD_T(String CCCD_T) {
        this.CCCD_T = CCCD_T;
    }

    public String getCCCD_S() {
        return CCCD_S;
    }

    public void setCCCD_S(String CCCD_S) {
        this.CCCD_S = CCCD_S;
    }

    public String getSDT() {
        return SDT;
    }

    public void setSDT(String SDT) {
        this.SDT = SDT;
    }    
    
}
