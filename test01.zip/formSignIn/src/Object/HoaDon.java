/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Object;

/**
 *
 * @author Tran Bao
 */
public class HoaDon {
    private String SoHoaDon;
    private String SoHopDong;
    private String MaNV;
    private int SoXeThue;
    private String NgayHoaDon;
    private double TraTruoc;
    private double TraSau;
    private String PhiPS;
    private String LyDo;
    private double TriGia;
    private double ThanhTien;

    public HoaDon(String SoHoaDon, String SoHopDong, String MaNV, int SoXeThue, String NgayHoaDon, double TraTruoc, double TraSau, String PhiPS, String LyDo, double TriGia, double ThanhTien) {
        this.SoHoaDon = SoHoaDon;
        this.SoHopDong = SoHopDong;
        this.MaNV = MaNV;
        this.SoXeThue = SoXeThue;
        this.NgayHoaDon = NgayHoaDon;
        this.TraTruoc = TraTruoc;
        this.TraSau = TraSau;
        this.PhiPS = PhiPS;
        this.LyDo = LyDo;
        this.TriGia = TriGia;
        this.ThanhTien = ThanhTien;
    }

    public HoaDon() {
    }

    public String getSoHoaDon() {
        return SoHoaDon;
    }

    public void setSoHoaDon(String SoHoaDon) {
        this.SoHoaDon = SoHoaDon;
    }

    public String getSoHopDong() {
        return SoHopDong;
    }

    public void setSoHopDong(String SoHopDong) {
        this.SoHopDong = SoHopDong;
    }

    public String getMaNV() {
        return MaNV;
    }

    public void setMaNV(String MaNV) {
        this.MaNV = MaNV;
    }

    public int getSoXeThue() {
        return SoXeThue;
    }

    public void setSoXeThue(int SoXeThue) {
        this.SoXeThue = SoXeThue;
    }

    public String getNgayHoaDon() {
        return NgayHoaDon;
    }

    public void setNgayHoaDon(String NgayHoaDon) {
        this.NgayHoaDon = NgayHoaDon;
    }

    public double getTraTruoc() {
        return TraTruoc;
    }

    public void setTraTruoc(double TraTruoc) {
        this.TraTruoc = TraTruoc;
    }

    public double getTraSau() {
        return TraSau;
    }

    public void setTraSau(double TraSau) {
        this.TraSau = TraSau;
    }

    public String getPhiPS() {
        return PhiPS;
    }

    public void setPhiPS(String PhiPS) {
        this.PhiPS = PhiPS;
    }

    public String getLyDo() {
        return LyDo;
    }

    public void setLyDo(String LyDo) {
        this.LyDo = LyDo;
    }

    public double getTriGia() {
        return TriGia;
    }

    public void setTriGia(double TriGia) {
        this.TriGia = TriGia;
    }

    public double getThanhTien() {
        return ThanhTien;
    }

    public void setThanhTien(double ThanhTien) {
        this.ThanhTien = ThanhTien;
    }
    
    
    
    
    
}
