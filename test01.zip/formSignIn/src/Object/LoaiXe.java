/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Object;

/**
 *
 * @author Tran Bao
 */
public class LoaiXe {
    private String MaLX;
    private String TenLX;
    private int SoCho;
    private int SoLuong;
    private int Gia;
    private int NgoaiGio;

    public LoaiXe() {
    }
    
    

    public LoaiXe(String MaLX, String TenLX, int SoCho, int SoLuong, int Gia, int NgoaiGio) {
        this.MaLX = MaLX;
        this.TenLX = TenLX;
        this.SoCho = SoCho;
        this.SoLuong = SoLuong;
        this.Gia = Gia;
        this.NgoaiGio = NgoaiGio;
    }

    public String getMaLX() {
        return MaLX;
    }

    public void setMaLX(String MaLX) {
        this.MaLX = MaLX;
    }

    public String getTenLX() {
        return TenLX;
    }

    public void setTenLX(String TenLX) {
        this.TenLX = TenLX;
    }

    public int getSoCho() {
        return SoCho;
    }

    public void setSoCho(int SoCho) {
        this.SoCho = SoCho;
    }

    public int getSoLuong() {
        return SoLuong;
    }

    public void setSoLuong(int SoLuong) {
        this.SoLuong = SoLuong;
    }

    public int getGia() {
        return Gia;
    }

    public void setGia(int Gia) {
        this.Gia = Gia;
    }

    public int getNgoaiGio() {
        return NgoaiGio;
    }

    public void setNgoaiGio(int NgoaiGio) {
        this.NgoaiGio = NgoaiGio;
    }
    
    
    
    
}
