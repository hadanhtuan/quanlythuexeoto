
package formsignin;

/**
 *
 * @author Tran Bao
 */
public class FormSignIn {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Hello World");
    }
    
}
